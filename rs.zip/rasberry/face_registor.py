from pathlib import Path
import sys
import os
import cv2

from src.utils.common import dump_bin, read_yaml, colorstr, LOGGER, config_table, Loading, INFO, Eror, Done, Warning
from src.utils.videoplayer import VideoPlayer
from src.constants import CONFIG_FILE_PATH
from src.database import FaceRegistration



FILE = Path(__file__).resolve()
ROOT = FILE.parents[0]  # YOLOv5 root directory
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))  # add ROOT to PATH
ROOT = Path(os.path.relpath(ROOT, Path.cwd())) 


config = read_yaml(CONFIG_FILE_PATH)


def main(source, 
         flip=False,
         face_embeding_save = ROOT / f"{config.facerecognition.face_save_database}",
         face_xml_path =  ROOT / f"{config.facerecognition.face_reidentification_xml_path}"
         
):
    

    model = FaceRegistration(face_xml_path)
    skip_frame = 25
    skip = 0
    count = 0
    frame_no = 0

    try:
        LOGGER.info(f"{Loading}  video/webcam is loadding")
        player = VideoPlayer(
                source=source, flip=flip, fps=25, skip_first_frames=5)
        
        player.start()
        embeddings = []
        while True:
            frame = player.next()
            skip += 1
            if  skip < skip_frame: continue
            skip = 0

            embedding = model.generate_embedding(frame, show_faces=True)

            if embedding.size != 0:
                frame_no +=  skip_frame
                LOGGER.info(f"{INFO} Frame {frame_no} is registered")
                embeddings.append(embedding)
                count += 1
            else:
                frame_no +=  skip_frame
                LOGGER.warning(f"{Warning}  Frame {frame_no} is no face detection skiping Frame")


            if count >= 15: 
                dump_bin(face_embeding_save, embeddings)
                break
    
        
    except KeyboardInterrupt:
        LOGGER.warning("Keyboard Interrupted")
    except Exception as e:
        print('yesssssss')
        LOGGER.error(f"{Eror}: {e}")

    else:
        LOGGER.info(f"{Done} Face Registration Done")
        if player is not None:
            player.stop()
        cv2.destroyAllWindows()
    



if __name__ == "__main__":

    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', default="/home/ghost/tensorgo/ADAM/adam/resizeed_video.mp4", help='video stream source')
    parser.add_argument('--flip', action='store_true', help='flip the image when you are using webcam')
    opt = parser.parse_args()

    config.update(opt.__dict__)
    config_table(config)

    main(config.source, config.flip)
        




            


        
