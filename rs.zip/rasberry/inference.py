import argparse
import sys
import os
from pathlib import Path
import mediapipe as mp
import cv2
import time
from collections import deque

from src.utils.common import check_requirements, read_yaml, colorstr, LOGGER, config_table, Loading, Done, Fps, Eror
from src.constants import CONFIG_FILE_PATH
from src.distraction import distraction
from src.drowsiness import drowsiness
from src.facerecognition import FaceRecognition
from src.objectdetection import ObjectDetections
from src.utils.videoplayer import VideoPlayer



FILE = Path(__file__).resolve()
ROOT = FILE.parents[0]  # YOLOv5 root directory
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))  # add ROOT to PATH
ROOT = Path(os.path.relpath(ROOT, Path.cwd()))  # relative

check_requirements(ROOT / 'requirements.txt')
config = read_yaml(CONFIG_FILE_PATH)



def main(
        source ,                                                                                                                                     
        flip:bool=False,
        use_popup:bool = True,
        object_openvinio_f16_xml_path:Path = ROOT / f"{config.ObjectDetections.openvinio_f16_xml_path}", 
        face_reidentification_xml_path:Path = ROOT / f"{config.facerecognition.face_reidentification_xml_path}" ,
        face_save_database:Path = ROOT / f"{config.facerecognition.face_save_database}",
):

    pass

  

    LOGGER.info(f"{Loading} Face Recognition model start loading... ", )
    face_reco = FaceRecognition(database_pkl=face_save_database
                           , face_xml_path=face_reidentification_xml_path)
    
    LOGGER.info(f"{Done} Face Recognition model loaded \n")
    
    LOGGER.info(f"{Loading} Object Detection model start loading...")
    
    object_detection = ObjectDetections(openvinon_f16_path=object_openvinio_f16_xml_path)
    LOGGER.info(f"{Done} Object Detection model loaded \n")

    LOGGER.info(f"{Loading} Mediapipe  model start loading...")
    mp_face_mesh = mp.solutions.face_mesh
    face_mesh = mp_face_mesh.FaceMesh(static_image_mode=False, min_detection_confidence=0.5,min_tracking_confidence=0.5)
    LOGGER.info(f"{Done} Mediapipe model loaded \n")

    
    try:
        LOGGER.info(f"{Loading}  video/webcam is loadding")
        # player = VideoPlayer(
        #         source=source, flip=flip, fps=30, skip_first_frames=0)
        
        # player.start()
        cap = cv2.VideoCapture(source)


        counter = 0
        face = ''
        frame_count = 0
        min_tolerance = 5.0
        min_frame = 5
        prev_frame_time = 0
        total_time =deque(maxlen=500)

        # store = [None]* 5
        store = deque(maxlen=5)
        

        while True:
            # frame = player.next()
            ret, frame = cap.read()

            if flip:
                frame = cv2.fiip(frame, 1)

            if frame is None:
                LOGGER.info(f"{Done} Video player Done")
                break
                
            "object detection"
            mobile = object_detection.mobile(frame=frame)

            """logic for Distraction and drowsiness"""
            flip = cv2.flip(frame, 1)
            dist_img = cv2.cvtColor(flip, cv2.COLOR_BGR2RGB)
            dist_img.flags.writeable = False
            results = face_mesh.process(dist_img)
            dist_img.flags.writeable = True
            # store = store[1:] + [results]
            store.append(results)

            distra = distraction(frame, results)
            
            drows = ''
            if not distra:
                frame_count, drows = drowsiness(frame, results, min_tolerance, min_frame, frame_count)

            """ Face Recognition  """
            
            counter += 1
            if counter % 10 == 0:
                """face  and recognition"""
                # print("yees")
                face = face_reco.recognition(flip, store)

            

            new_frame_time = time.time()
            fpssss = int(1/(new_frame_time-prev_frame_time))
            prev_frame_time = new_frame_time
            total_time.append(fpssss)

            if counter % 500 == 499:
                avgfps = int(sum(total_time)/ len(total_time))
                LOGGER.info(f"{Fps}  {avgfps}")

            cv2.putText(frame, f"Verified Driver: {face}", (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2, cv2.LINE_AA)
            cv2.putText(frame, f"Distraction: {distra}", (30, 60), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)
            cv2.putText(frame, f"Drowsiness: {drows}", (30, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2, cv2.LINE_AA)
            cv2.putText(frame, f"Mobile: {mobile}", (30, 140), cv2.FONT_HERSHEY_SIMPLEX, 1, (123, 140, 210), 2, cv2.LINE_AA)
            cv2.putText(frame, f'FPS: {fpssss}', (30, 180), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)

            if  use_popup:
                cv2.imshow(winname="Akhilesh", mat=frame)
                key = cv2.waitKey(1)
                # escape = 27
                if key == 27:
                    break


    except KeyboardInterrupt:
        LOGGER.warning("Keyboard Interrupted")

    except Exception as e:
        LOGGER.error(f"{Eror}: {e}")

    finally:
        # if player is not None:
        #     player.stop()

        cap.close()

        if total_time:
            lastfps = int(sum(total_time)/ len(total_time))
            LOGGER.info(f"{Fps}  {lastfps}")

        cv2.destroyAllWindows()
    






if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument('--source', default="/home/ghost/tensorgo/ADAM/adam/resizeed_video.mp4", help='video stream source')
    parser.add_argument('--flip', action='store_true', help='flip the image when you are using webcam')
    parser.add_argument('--use-popup', action='store_false', help='show the infence video')
    opt = parser.parse_args()

    config.update(opt.__dict__)
    config_table(config)
    
    main(config.source, config.flip, config.use_popup)

    




