from setuptools import setup, find_packages
from pathlib import Path
import pkg_resources as pkg


## edit below variables as per your requirements -
REPO_NAME = "ADAM" 
AUTHOR_USER_NAME = "Akhilesh, sandeep" # update as per your need
SRC_REPO = "src" # example sklearn etc
LIST_OF_REQUIREMENTS = [] # core dependencies


FILE = Path(__file__).resolve()
PARENT = FILE.parent
REQUIREMENTS = [f'{x.name}{x.specifier}' for x in pkg.parse_requirements((PARENT / 'requirements.txt').read_text())]

setup(
    name=SRC_REPO,
    version="0.0.1",
    author=AUTHOR_USER_NAME,
    python_requires='>=3.7',
    description="A small package",
    long_description=None,
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    python_requires=">=3.7",
    install_requires=REQUIREMENTS 
)