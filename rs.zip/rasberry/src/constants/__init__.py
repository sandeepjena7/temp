from pathlib import Path

CONFIG_FILE_PATH = Path("configs/config.yaml")