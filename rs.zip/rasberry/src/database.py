import mediapipe as mp
from openvino.inference_engine import  IECore
import os
from src.utils.common import  LOGGER, colorstr
import cv2
import numpy as np

class FaceRegistration:
    def __init__(self, face_xml_path):


        Loading = colorstr("yellow", "Loading:")
        Done = colorstr("green", "Done:")
        
        if (not os.path.isfile(face_xml_path)) | ( not os.path.isfile(str(face_xml_path).replace(".xml", ".bin"))):
            raise FileNotFoundError(f".xml and .bin File not Found 🗂️")

        LOGGER.info(f"{Loading} Face Recognition model start loading... ", )
        face_reco_net = IECore().read_network(model=face_xml_path, weights=str(face_xml_path).replace(".xml", ".bin"))
        face_reco_exec = IECore().load_network(network=face_reco_net, device_name='CPU')
        input_blob = next(iter(face_reco_net.input_info))
        output_blob = next(iter(face_reco_net.outputs))
        input_shape = face_reco_net.input_info[input_blob].input_data.shape
        LOGGER.info(f"{Done} Face Recognition model loaded \n")


        LOGGER.info(f"{Loading} Mediapipe  model start loading...")
        mp_face_mesh = mp.solutions.face_mesh
        face_mesh = mp_face_mesh.FaceMesh(static_image_mode=False, min_detection_confidence=0.5,min_tracking_confidence=0.5)
        LOGGER.info(f"{Done} Mediapipe model loaded \n")                                        
        self.__dict__.update(locals())                                                                                                                          

    def generate_embedding(self, frame, show_faces=False):

        flip = cv2.flip(frame, 1)
        dist_img = cv2.cvtColor(flip, cv2.COLOR_BGR2RGB)
    
        dist_img.flags.writeable = False
        results = self.face_mesh.process(dist_img)
        dist_img.flags.writeable = True


        if results.multi_face_landmarks:
            for faceLms in results.multi_face_landmarks:

                h, w, c = frame.shape
                cx_min=  w
                cy_min = h
                cx_max= cy_max= 0
                for lm in faceLms.landmark:
                    cx, cy = min(int(lm.x * w), w - 1 ), min(int(lm.y * h), h - 1)
                    if cx<cx_min:
                        cx_min=cx
                    if cy<cy_min:
                        cy_min=cy
                    if cx>cx_max:
                        cx_max=cx
                    if cy>cy_max:
                        cy_max=cy
            

            face = flip[cy_min-15:cy_max+5, cx_min:cx_max]
            if show_faces:
                cv2.imshow("FACE", face)
                cv2.waitKey(100)

            face = cv2.resize(face, (self.input_shape[3], self.input_shape[2]))      
            face = face.transpose((2, 0, 1)) 
            face = face[None]

            outputs = self.face_reco_exec.infer(inputs={self.input_blob: face})
            embeddings = outputs[self.output_blob]
            embeddings = embeddings.reshape(256)
            
            return embeddings
        
        return np.empty(0)



