import os
import pickle
from openvino.inference_engine import  IECore
from scipy.spatial.distance import cosine
import cv2
from pathlib import Path



class FaceRecognition:
    def __init__(self,database_pkl:Path, face_xml_path:Path):
        if not os.path.isfile(database_pkl):
            raise FileNotFoundError(f"pkl File not Found 🗂️")

        if (not os.path.isfile(face_xml_path)) | ( not os.path.isfile(str(face_xml_path).replace(".xml", ".bin"))):
            raise FileNotFoundError(f".xml and .bin File not Found 🗂️")

        face_reco_net = IECore().read_network(model=face_xml_path, weights=str(face_xml_path).replace(".xml", ".bin"))
        face_reco_exec = IECore().load_network(network=face_reco_net, device_name='CPU')
        input_blob = next(iter(face_reco_net.input_info))
        output_blob = next(iter(face_reco_net.outputs))
        input_shape = face_reco_net.input_info[input_blob].input_data.shape

        
        with open(database_pkl, 'rb') as f:
            embed2 = pickle.load(f)
        # verify_embed = embed2['subject']
        verify_embed = embed2


        self.__dict__.update(locals())


    def _get_face_embedding(self, frame):
        face = cv2.resize(frame, (self.input_shape[3], self.input_shape[2]))
        face = face.transpose((2, 0, 1)) 
        face = face[None]

        outputs = self.face_reco_exec.infer(inputs={self.input_blob: face})
        embeddings = outputs[self.output_blob]
        embeddings = embeddings.reshape(256).tolist()

        return embeddings
    
    def recognition(self, frame, resutl_stores, threshold=0.5, min_no_img_match=5):
        detection = ''

        for results in reversed(resutl_stores):
            if results.multi_face_landmarks:
                for faceLms in results.multi_face_landmarks:

                    h, w, c = frame.shape
                    cx_min=  w
                    cy_min = h
                    cx_max= cy_max= 0
                    for lm in faceLms.landmark:
                        cx, cy = min(int(lm.x * w), w - 1 ), min(int(lm.y * h), h - 1)
                        if cx<cx_min:
                            cx_min=cx
                        if cy<cy_min:
                            cy_min=cy
                        if cx>cx_max:
                            cx_max=cx
                        if cy>cy_max:
                            cy_max=cy
                

                face = frame[cy_min-15:cy_max+5, cx_min:cx_max]
                face_embd = self._get_face_embedding(face)
                # distance = cosine(face_embd, self.verify_embed)
                tota_match_img = sum(map(lambda x: True if cosine(x, face_embd) < threshold else False, self.verify_embed))
                # print(tota_match_img)
                if tota_match_img > min_no_img_match:
                    detection = 'Verified'
                    return detection
                else:
                    return detection
        
        return detection
        