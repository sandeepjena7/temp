import os
import cv2
from openvino import runtime as ov
from ensure import ensure_annotations
from pathlib import Path



class ObjectDetections:
    @ensure_annotations
    def __init__(self, openvinon_f16_path:Path, thresh:float=0.6):
        if not os.path.isfile(openvinon_f16_path):
            raise FileNotFoundError(f" File not Found 🗂️")
        
        ie_core = ov.Core()
        model = ie_core.read_model(model=openvinon_f16_path)
        compiled_model = ie_core.compile_model(model=model,  device_name="CPU")
        input_layer = compiled_model.input(0)
        output_layer = compiled_model.output(0)
        height, width = list(input_layer.shape)[1:3]

        self.__dict__.update(locals())
    
    def mobile(self, frame):

        input_img = cv2.resize(src=frame, dsize=(self.width, self.height))
        input_img = input_img[None]
        results = self.compiled_model([input_img])[self.output_layer]

        h, w = frame.shape[:2]
        results = results.squeeze()
        boxes = []
        labels = []
        scores = []

        for _, label, score, xmin, ymin, xmax, ymax in results:
            if not (label == 77): continue
            boxes.append(
                tuple(map(int, (xmin * w, ymin * h, (xmax - xmin) * w, (ymax - ymin) * h)))
            )
            labels.append(int(label))
            scores.append(float(score))
    
        indices = cv2.dnn.NMSBoxes(
            bboxes=boxes, scores=scores, score_threshold=self.thresh, nms_threshold=0.6
        )

        detection = ""
        if len(indices) == 0:
            return detection

        detection = "Detected"
        return detection
